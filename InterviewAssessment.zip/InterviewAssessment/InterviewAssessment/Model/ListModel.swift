//
//  ListModel.swift
//  InterviewAssessment
//
//  Created by Test on 19/06/20.
//  Copyright © 2020 Ganapathy, Sandhya. All rights reserved.
//

import Foundation
struct ListModel {
    var imageHref: String?
    var title: String?
    var description: String?
    init(dictionary: NSDictionary) {
        self.imageHref = dictionary["imageHref"] as? String ?? ""
        self.description = dictionary["description"] as? String ?? ""
        self.title = dictionary["title"] as? String ?? ""
    }
}
