//
//  ListTableViewCell.swift
//  InterviewAssessment
//
//  Created by Test on 19/06/20.
//  Copyright © 2020 Ganapathy, Sandhya. All rights reserved.
//

import UIKit
class ListTableViewCell: UITableViewCell {
    // UIElements
    let titleLabel: UILabel = {
        let titleLabel = UILabel()
        titleLabel.numberOfLines = 0
        titleLabel.lineBreakMode = .byClipping
        titleLabel.font = UIFont(name: "AvenirNext-Bold", size: 28.0)
        titleLabel.textAlignment = .center
        titleLabel.textColor = UIColor.black
        return titleLabel
    }()
    let descriptionLabel: UILabel = {
        let descriptionLabel = UILabel()
        descriptionLabel.numberOfLines = 0
        descriptionLabel.font = UIFont.systemFont(ofSize: 16)
        descriptionLabel.lineBreakMode = .byClipping
        descriptionLabel.textColor = .black
        return descriptionLabel
    }()
    let imgView: UIImageView = {
        let imgView = UIImageView()
        imgView.image = UIImage(named: "no_Image")
        imgView.sizeToFit()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()

    // MARK: - View Related Methods
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(imgView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(descriptionLabel)
        self.autolayoutUsingConstraint()
    }
    override func prepareForReuse() {
        super.prepareForReuse()
        self.imgView.image = nil
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func autolayoutUsingConstraint() {
        self.imgView.translatesAutoresizingMaskIntoConstraints = false
        self.titleLabel.translatesAutoresizingMaskIntoConstraints = false
        self.descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        
        // ImgView
        let imgViewTop = NSLayoutConstraint(item: imgView, attribute: .top, relatedBy: .equal, toItem: self.contentView, attribute: .top, multiplier: 1.0, constant: 10)
        let imgViewTrailing = NSLayoutConstraint(item: imgView, attribute: .trailing, relatedBy: .equal, toItem: self.contentView, attribute: .trailing, multiplier: 1.0, constant: 0)
        let imgViewLeading = NSLayoutConstraint(item: imgView, attribute: .leading, relatedBy: .equal, toItem: self.contentView, attribute: .leading, multiplier: 1.0, constant: 0)
        
        // TitleLabel
        let titleLabelTop = NSLayoutConstraint(item: titleLabel, attribute: .top, relatedBy: .equal, toItem: self.imgView, attribute: .bottom, multiplier: 1.0, constant: 10)
        let titleLabelTrailing = NSLayoutConstraint(item: titleLabel, attribute: .trailing, relatedBy: .equal, toItem: self.contentView, attribute: .trailing, multiplier: 1.0, constant: 0)
        let titleLabelLeading = NSLayoutConstraint(item: titleLabel, attribute: .leading, relatedBy: .equal, toItem: self.contentView, attribute: .leading, multiplier: 1.0, constant: 0)
        
        //DescriptionLabel
        let descriptionLabelTop = NSLayoutConstraint(item: descriptionLabel, attribute: .top, relatedBy: .equal, toItem: self.titleLabel, attribute: .bottom, multiplier: 1.0, constant: 10)
        let descriptionLabelTrailing = NSLayoutConstraint(item: descriptionLabel, attribute: .trailing, relatedBy: .equal, toItem: self.contentView, attribute: .trailing, multiplier: 1.0, constant: 0)
        let descriptionLabelLeading = NSLayoutConstraint(item: descriptionLabel, attribute: .leading, relatedBy: .equal, toItem: self.contentView, attribute: .leading, multiplier: 1.0, constant: 0)
        let descriptionLabelBottom = NSLayoutConstraint(item: descriptionLabel, attribute: .bottom, relatedBy: .equal, toItem: self.contentView, attribute: .bottom, multiplier: 1.0, constant: -10)
        
        self.contentView.addConstraints([imgViewTop, imgViewTrailing, imgViewLeading, titleLabelTop, titleLabelTrailing, titleLabelLeading, descriptionLabelTop, descriptionLabelTrailing, descriptionLabelLeading, descriptionLabelBottom])
    }
}
