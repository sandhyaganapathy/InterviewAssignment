//
//  ListTableViewController.swift
//  InterviewAssessment
//
//  Created by Sandhya Ganapathy on 19/06/20.
//  Copyright © 2020 Ganapathy, Sandhya. All rights reserved.
//

import UIKit
import SDWebImage
class ListTableViewController: UITableViewController {
    //Cell Identifier
    let cellIdentifier: String = "CellIdentifier"
    var listViewModel = ListViewModel()
    let myActivityIndicator = UIActivityIndicatorView()
    var navigationTitleText: String = "" {
        didSet {
            self.title = navigationTitleText
        }
    }
    var placeholderImage: UIImage = {
        let placeholderImg = UIImage(named: "no_Image")
        return placeholderImg!
    }()
    lazy var refreshCntrl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self,
                                 action: #selector(ListTableViewController.handleRefresh(_:)),
                                 for: UIControl.Event.valueChanged)
        refreshControl.tintColor = UIColor.red
        return refreshControl
    }()
    // MARK: - ViewController Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        //TableView Property setting
        self.tableView.estimatedRowHeight = UITableView.automaticDimension
        self.tableView.tableFooterView = UIView.init()
        self.tableView.rowHeight = UITableView.automaticDimension
        self.tableView.register(ListTableViewCell.classForCoder(), forCellReuseIdentifier: cellIdentifier)
        self.tableView.translatesAutoresizingMaskIntoConstraints = false
        self.tableView.addSubview(self.refreshCntrl)
        // Activity Indicator
        self.myActivityIndicator.center = self.view.center
        self.myActivityIndicator.hidesWhenStopped = true
        if #available(iOS 13.0, *) {
            self.myActivityIndicator.style = .medium
        } else {
            // Fallback on earlier versions
            self.myActivityIndicator.style = .gray
        }
        self.view.addSubview(myActivityIndicator)
        self.myActivityIndicator.startAnimating()
        // Webservice Call
        self.callApiToGetJSONData()
    }
    // MARK: - API Calls
    func callApiToGetJSONData() {
        if Reachability.isConnectedToNetwork() {
            let urlString = URL(string: Constants.URLStrings.webServiceUrlString)
            let urlRequest = URLRequest(url: urlString!)
            listViewModel.fetchJsonAndSaving(urlRequest: urlRequest, completion: {(successOrFailure, responseObject) in
                if successOrFailure {
                    DispatchQueue.main.async {
                        print(responseObject!)
                        self.tableView.reloadData()
                        if let response = responseObject {
                            self.navigationTitleText = response["title"] as? String ?? ""
                        }
                        self.myActivityIndicator.stopAnimating()
                    }
                } else {
                    //Failure Case
                    self.myActivityIndicator.stopAnimating()
                }
            })
        } else {
            self.myActivityIndicator.stopAnimating()
            let msgString = "No Internet connection.Please check your network connection"
            let alertController = UIAlertController(title: "",
                                                    message: msgString, preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(defaultAction)
            present(alertController, animated: true, completion: nil)
        }
    }
    // MARK: - Handle Refresh
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        listViewModel.itemsArray.removeAll()
        self.callApiToGetJSONData()
        refreshControl.endRefreshing()
    }
    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  listViewModel.numberOfRowsInSection()
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? ListTableViewCell
        if cell == nil {
            cell = ListTableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: cellIdentifier)
        }
        let model = listViewModel.itemsArray[indexPath.row] as ListModel
        if let imgURLString = model.imageHref {
            let imageUrl = URL(string: imgURLString)
            cell?.imgView.sd_setShowActivityIndicatorView(true)
            if #available(iOS 13.0, *) {
                cell?.imgView.sd_setIndicatorStyle(.medium)
            } else {
                // Fallback on earlier versions
                cell?.imgView.sd_setIndicatorStyle(.gray)
            }
            cell?.imgView.sd_setImage(with: imageUrl, placeholderImage: placeholderImage,
                                      options: .forceTransition, completed: nil)
            cell?.titleLabel.text = listViewModel.itemsArray[indexPath.row].title
            cell?.descriptionLabel.text = listViewModel.itemsArray[indexPath.row].description
            cell?.selectionStyle = .none
            return cell ?? UITableViewCell()
        }
        return UITableViewCell()
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
