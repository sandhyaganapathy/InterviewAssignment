//
//  ListViewModel.swift
//  InterviewAssessment
//
//  Created by Test on 19/06/20.
//  Copyright © 2020 Ganapathy, Sandhya. All rights reserved.
//

import Foundation
class ListViewModel: NSObject {
    var itemsArray = [ListModel]()
    // MARK: - APIClient call
    func fetchJsonAndSaving(urlRequest: URLRequest,
                            completion: @escaping (_ success: Bool, _ object: AnyObject?) -> () ) {
        APIClient.client.fetchDataTask(urlRequest: urlRequest, completion: { (successOrFailure, responseObject) in
            if successOrFailure {
                if let responseObj = responseObject {
                    if let items = responseObj["rows"] as? [[String: Any]] {
                        completion(true, responseObj)
                        for item in items {
                            let model = ListModel(dictionary: item as NSDictionary )
                            self.itemsArray.append(model)
                        }
                    }
                }
            }
        })
    }
    // MARK: - To Get Row Count
    func numberOfRowsInSection() -> Int {
        return itemsArray.count
    }
}
