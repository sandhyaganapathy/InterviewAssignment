//
//  Constants.swift
//  InterviewAssessment
//
//  Created by Sandhya Ganapathy on 19/06/20.
//  Copyright © 2020 Ganapathy, Sandhya. All rights reserved.
//

struct Constants {
    // MARK: - API Related URLs
    struct URLStrings {
        static let webServiceUrlString = "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json"
    }
}
